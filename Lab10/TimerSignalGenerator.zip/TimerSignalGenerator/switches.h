#ifndef SWITCHES_H
#define SWITCHES_H

void switches_init(void);
int switch_get(PIN pin);

#endif // SWITCHES_H

// *******************************Arm University Program Copyright � ARM Ltd 2021*************************************   
