#include "platform.h"
#include "tone.h"
#include "delay.h"
#include "gpio.h"
#include "leds.h"


//Uncomment to play with interrupts, comment to play with blocking.
//#define USE_INTERRUPTS

int main(void) {
	leds_init();
	
	wavetype wave = SQUARE;
	tone_init();
  __enable_irq();

	while(1) {

#ifdef USE_INTERRUPTS

//Write your code to use interrupts here

#else

//Write your code to use busy-wait here

#endif

	}
}

// *******************************ARM University Program Copyright © ARM Ltd 2016*************************************
