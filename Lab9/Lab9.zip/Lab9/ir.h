#ifndef IR_H
#define IR_H

void ir_init(void);
int ir_measure(void);

#endif // IR_H

// *******************************Arm University Program Copyright � Arm Ltd 2021*************************************   
